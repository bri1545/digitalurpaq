"""
Script to scrape Digital Urpaq website and create knowledge base
"""
import json
from web_scraper import get_website_text_content


def scrape_digital_urpaq():
    """Scrape information from Digital Urpaq website"""
    
    # Main website URL (note: the URL in requirements had typo, correcting to likely URL)
    base_url = "https://digitalurpaq.edu.kz/ru/index.htm"
    
    knowledge_base = {
        "general_info": "",
        "schedules": "",
        "clubs": "",
        "directions": "",
        "navigation": "",
        "contacts": ""
    }
    
    # Try to scrape main page
    try:
        print("Scraping main page...")
        main_content = get_website_text_content(base_url)
        if main_content:
            knowledge_base["general_info"] = main_content
            print("✓ Main page scraped successfully")
        else:
            print("⚠ Main page content is empty")
    except Exception as e:
        print(f"⚠ Error scraping main page: {e}")
    
    # Common pages to try
    pages = [
        ("about", "general_info"),
        ("schedule", "schedules"),
        ("clubs", "clubs"),
        ("directions", "directions"),
        ("contacts", "contacts"),
    ]
    
    for page, category in pages:
        try:
            url = f"https://digitalurpaq.edu.kz/ru/{page}.htm"
            print(f"Scraping {url}...")
            content = get_website_text_content(url)
            if content:
                knowledge_base[category] += f"\n\n{content}"
                print(f"✓ {page} page scraped")
        except Exception as e:
            print(f"⚠ Could not scrape {page}: {e}")
    
    # Add some default information if scraping fails
    if not knowledge_base["general_info"]:
        knowledge_base["general_info"] = """
Дворец школьников Digital Urpaq - современный образовательный центр в городе Петропавловск.
Мы предлагаем различные кружки и секции для детей и подростков в области технологий, 
искусства, спорта и науки.
"""
    
    if not knowledge_base["navigation"]:
        knowledge_base["navigation"] = """
Навигация по зданию:
- 1 этаж: Администрация, информационный центр, гардероб
- 2 этаж: Компьютерные классы, робототехника, IT-лаборатории
- 3 этаж: Творческие мастерские, музыкальные классы
- 4 этаж: Спортивный зал, танцевальные студии
"""
    
    if not knowledge_base["schedules"]:
        knowledge_base["schedules"] = """
График работы Дворца школьников:
Понедельник - Пятница: 09:00 - 20:00
Суббота: 10:00 - 18:00
Воскресенье: Выходной

Занятия кружков проводятся во второй половине дня с 14:00 до 19:00.
"""
    
    if not knowledge_base["clubs"]:
        knowledge_base["clubs"] = """
Направления и кружки:
1. IT и программирование: Python, веб-разработка, создание игр
2. Робототехника: LEGO Mindstorms, Arduino
3. Дизайн: графический дизайн, 3D-моделирование
4. Творчество: рисование, музыка, танцы
5. Наука: физика, химия, биология
6. Спорт: футбол, баскетбол, шахматы
"""
    
    if not knowledge_base["contacts"]:
        knowledge_base["contacts"] = """
Контактная информация:
Приемная: 8 (7152) 34-02-40
Ресепшн: 8 (7152) 50-17-03
Адрес: г. Петропавловск, Дворец школьников Digital Urpaq
Режим работы: Пн-Пт 09:00-20:00, Сб 10:00-18:00
"""
    
    if not knowledge_base["directions"]:
        knowledge_base["directions"] = """
Основные направления Дворца школьников:
- Научно-биологическое
- IT - Информационные технологии
- Художественно-эстетическое
- Художественная школа
- Бизнес школа
- Журналистика и медиатехнологии
- Дебатный клуб и КВН
"""
    
    # Save to JSON file
    with open("knowledge_base.json", "w", encoding="utf-8") as f:
        json.dump(knowledge_base, f, ensure_ascii=False, indent=2)
    
    print("\n✓ Knowledge base created and saved to knowledge_base.json")
    return knowledge_base


if __name__ == "__main__":
    scrape_digital_urpaq()

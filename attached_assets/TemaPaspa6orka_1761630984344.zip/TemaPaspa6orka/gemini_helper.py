# Based on python_gemini blueprint integration
import os
from google import genai
from google.genai import types


# IMPORTANT: KEEP THIS COMMENT
# Follow these instructions when using this blueprint:
# - Note that the newest Gemini model series is "gemini-2.5-flash" or gemini-2.5-pro"
#   - do not change this unless explicitly requested by the user
# - Sometimes the google genai SDK has occasional type errors. You might need to run to validate, at time.  
# The SDK was recently renamed from google-generativeai to google-genai. This file reflects the new name and the new APIs.

# This API key is from Gemini Developer API Key, not vertex AI API Key
# Lazy initialization - client will be created when first needed
_client = None


def get_client():
    """Get or create Gemini client with lazy initialization"""
    global _client
    if _client is None:
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY environment variable is not set")
        _client = genai.Client(api_key=api_key)
    return _client


def chat_with_context(user_message: str, context: str, conversation_history: list = None) -> str:
    """
    Chat with Gemini using context from knowledge base.
    
    Args:
        user_message: User's question
        context: Knowledge base context
        conversation_history: Optional list of previous messages
    
    Returns:
        AI response as string
    """
    system_prompt = f"""Ты — дружелюбный виртуальный помощник Дворца школьников Digital Urpaq в городе Петропавловск. 
Твоя задача — помогать гостям, учащимся и родителям, отвечая на их вопросы о расписании, кружках, 
направлениях, преподавателях и навигации по зданию.

Контекст информации о Дворце школьников:
{context}

Правила общения:
- Отвечай на русском языке
- Будь дружелюбным и полезным
- Если не знаешь точного ответа, честно скажи об этом и предложи обратиться к администрации
- Давай конкретные и понятные ответы
- Используй информацию из контекста выше для точных ответов"""

    try:
        # Build conversation parts
        contents = []
        
        # Add conversation history if exists
        if conversation_history:
            for msg in conversation_history:
                role = msg.get("role", "user")
                text = msg.get("content", "")
                contents.append(types.Content(role=role, parts=[types.Part(text=text)]))
        
        # Add current user message
        contents.append(types.Content(role="user", parts=[types.Part(text=user_message)]))
        
        client = get_client()
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=contents,
            config=types.GenerateContentConfig(
                system_instruction=system_prompt,
                temperature=0.7,
            )
        )
        
        return response.text or "Извините, произошла ошибка. Пожалуйста, попробуйте еще раз."
    
    except Exception as e:
        return f"Извините, произошла ошибка при обработке вашего запроса: {str(e)}"

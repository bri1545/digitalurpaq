import streamlit as st
import json
import os
from streamlit_lottie import st_lottie
import requests
from gemini_helper import chat_with_context


# Page configuration
st.set_page_config(
    page_title="Digital Urpaq Помощник",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        text-align: center;
        color: #2E86AB;
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        text-align: center;
        color: #6C757D;
        font-size: 1.1rem;
        margin-bottom: 2rem;
    }
    .quick-button {
        background-color: #2E86AB;
        color: white;
        border-radius: 10px;
        padding: 0.5rem 1rem;
        margin: 0.25rem;
        border: none;
        cursor: pointer;
        transition: all 0.3s;
    }
    .quick-button:hover {
        background-color: #1a5c7a;
        transform: translateY(-2px);
    }
    .chat-message {
        padding: 1rem;
        border-radius: 10px;
        margin: 0.5rem 0;
    }
    .user-message {
        background-color: #E3F2FD;
        margin-left: 2rem;
    }
    .bot-message {
        background-color: #F5F5F5;
        margin-right: 2rem;
    }
    .stButton > button {
        width: 100%;
        border-radius: 10px;
        background-color: #2E86AB;
        color: white;
        font-weight: 600;
    }
    .stButton > button:hover {
        background-color: #1a5c7a;
    }
</style>
""", unsafe_allow_html=True)


def load_lottie_url(url: str):
    """Load Lottie animation from URL"""
    try:
        r = requests.get(url)
        if r.status_code != 200:
            return None
        return r.json()
    except:
        return None


def load_knowledge_base():
    """Load knowledge base from JSON file"""
    try:
        with open("knowledge_base.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {
            "general_info": "Дворец школьников Digital Urpaq",
            "schedules": "",
            "clubs": "",
            "directions": "",
            "navigation": "",
            "contacts": ""
        }


def get_context_string(knowledge_base):
    """Convert knowledge base to context string"""
    context_parts = []
    for key, value in knowledge_base.items():
        if value:
            context_parts.append(f"{key.upper()}:\n{value}")
    return "\n\n".join(context_parts)


# Initialize session state
if "messages" not in st.session_state:
    st.session_state.messages = []
if "knowledge_base" not in st.session_state:
    st.session_state.knowledge_base = load_knowledge_base()
if "context" not in st.session_state:
    st.session_state.context = get_context_string(st.session_state.knowledge_base)


# Main Layout
col1, col2, col3 = st.columns([1, 2, 1])

with col2:
    st.markdown('<h1 class="main-header">🤖 Digital Urpaq Помощник</h1>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Ваш виртуальный гид по Дворцу школьников</p>', unsafe_allow_html=True)

# Robot Animation Section
col_anim1, col_anim2, col_anim3 = st.columns([1, 1, 1])

with col_anim2:
    # Load robot animation from Lottie
    lottie_robot = load_lottie_url("https://lottie.host/e0a9c7ac-78ab-4c90-9f0c-c0e8e7e61a3e/YwGN1JXSyT.json")
    if lottie_robot:
        st_lottie(lottie_robot, height=200, key="robot")
    else:
        # Fallback robot emoji
        st.markdown("<div style='text-align: center; font-size: 100px;'>🤖</div>", unsafe_allow_html=True)

# Greeting message
if not st.session_state.messages:
    st.info("👋 Привет! Я виртуальный помощник Дворца школьников Digital Urpaq. Я могу рассказать о расписании, кружках, преподавателях и помочь найти нужный кабинет. Задайте мне вопрос!")

# Quick action buttons
st.markdown("### 🎯 Быстрые вопросы")

col_btn1, col_btn2, col_btn3, col_btn4 = st.columns(4)

quick_questions = {
    "📅 Расписание": "Какое расписание работы Дворца школьников?",
    "🎨 Кружки": "Какие кружки есть в Дворце школьников?",
    "🗺️ Навигация": "Как найти нужный кабинет в здании?",
    "📞 Контакты": "Как связаться с администрацией Дворца?"
}

cols = [col_btn1, col_btn2, col_btn3, col_btn4]
for idx, (button_text, question) in enumerate(quick_questions.items()):
    with cols[idx]:
        if st.button(button_text, key=f"quick_{idx}"):
            # Add user message
            st.session_state.messages.append({"role": "user", "content": question})
            
            # Get AI response immediately
            if not os.environ.get("GEMINI_API_KEY"):
                bot_response = "⚠️ Для работы AI-помощника необходим API ключ Gemini. Пожалуйста, добавьте GEMINI_API_KEY в настройках."
            else:
                # Prepare conversation history
                conversation_history = []
                for msg in st.session_state.messages[:-1]:  # Exclude the last message (current)
                    conversation_history.append({
                        "role": msg["role"],
                        "content": msg["content"]
                    })
                
                bot_response = chat_with_context(
                    user_message=question,
                    context=st.session_state.context,
                    conversation_history=conversation_history
                )
            
            # Add bot response
            st.session_state.messages.append({"role": "model", "content": bot_response})
            st.rerun()

st.markdown("---")

# Chat Messages Display
st.markdown("### 💬 Чат")

chat_container = st.container()

with chat_container:
    for message in st.session_state.messages:
        role = message["role"]
        content = message["content"]
        
        if role == "user":
            st.markdown(f'<div class="chat-message user-message">👤 <strong>Вы:</strong> {content}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="chat-message bot-message">🤖 <strong>Помощник:</strong> {content}</div>', unsafe_allow_html=True)

# Chat Input
user_input = st.chat_input("Задайте ваш вопрос...")

if user_input:
    # Add user message
    st.session_state.messages.append({"role": "user", "content": user_input})
    
    # Check if GEMINI_API_KEY exists
    if not os.environ.get("GEMINI_API_KEY"):
        bot_response = "⚠️ Для работы AI-помощника необходим API ключ Gemini. Пожалуйста, добавьте GEMINI_API_KEY в настройках."
    else:
        # Get AI response
        with st.spinner("🤔 Думаю..."):
            # Prepare conversation history
            conversation_history = []
            for msg in st.session_state.messages[:-1]:  # Exclude the last message (current)
                conversation_history.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })
            
            bot_response = chat_with_context(
                user_message=user_input,
                context=st.session_state.context,
                conversation_history=conversation_history
            )
    
    # Add bot response
    st.session_state.messages.append({"role": "model", "content": bot_response})
    st.rerun()

# Sidebar with additional information
with st.sidebar:
    st.markdown("### 📖 О Дворце")
    
    with st.expander("🏢 Общая информация"):
        st.write(st.session_state.knowledge_base.get("general_info", "Информация загружается..."))
    
    with st.expander("🗺️ Навигация по этажам"):
        st.write(st.session_state.knowledge_base.get("navigation", "Информация загружается..."))
    
    with st.expander("📅 График работы"):
        st.write(st.session_state.knowledge_base.get("schedules", "Информация загружается..."))
    
    with st.expander("🎨 Направления"):
        st.write(st.session_state.knowledge_base.get("clubs", "Информация загружается..."))
    
    st.markdown("---")
    
    if st.button("🔄 Очистить чат", key="clear_chat_button"):
        st.session_state.messages.clear()
        st.rerun()
    
    st.markdown("---")
    st.caption("Digital Urpaq AI Assistant v1.0")
    st.caption("Powered by Gemini AI")
